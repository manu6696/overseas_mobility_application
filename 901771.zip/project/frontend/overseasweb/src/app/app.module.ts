import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { provideHttpClient, withInterceptorsFromDi } from '@angular/common/http';


import { AppComponent } from './app.component';
import { DashboardStudentComponent } from './dashboard-student/dashboard-student.component';
import { DashboardLecturerComponent } from './dashboard-lecturer/dashboard-lecturer.component';
import { DashboardStaffComponent } from './dashboard-staff/dashboard-staff.component';
import { HistoryTabComponent } from './history-tab/history-tab.component';
import { ApplicationStatusComponent } from './application-status/application-status.component';
import { ApplicationEditorComponent } from './application-editor/application-editor.component';
import { ApplicationCreatorComponent } from './application-creator/application-creator.component';
import { NavbarComponents } from './navbar/navbar.component';
import { RecordsVisualizerComponent } from './records-visualizer/records-visualizer.component';
import { AgreementVisualizerComponent } from './agreement-visualizer/agreement-visualizer.component';

// Services
import { AgreementHttpService } from './agreement-http.service';
import { ApplicationHttpService } from './application-http.service';
import { HostHttpService } from './host-http.service';
import { TranscriptRecordHttpService } from './transcript-record-http.service';
import { UserHttpService } from './user-http.service';
import { UserLoginComponent } from './user-login/user-login.component';
import { AppRoutingModule } from './/app-routing.module';
import { UserSignupComponent } from './user-signup/user-signup.component';
import { SocketioService } from './socketio.service';


import { MatGridListModule } from '@angular/material/grid-list';
import { MatCardModule } from '@angular/material/card';
import { MatMenuModule } from '@angular/material/menu';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatExpansionModule, MatAccordion } from '@angular/material/expansion';
import { MatDividerModule } from '@angular/material/divider';
import { MatDialogModule } from '@angular/material/dialog';
import { MatTooltipModule } from '@angular/material/tooltip';
import {
  MatDialogActions,
  MatDialogClose,
  MatDialogContent,
  MatDialogTitle,
} from '@angular/material/dialog';
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatInputModule} from '@angular/material/input';
import {MatSelectModule} from '@angular/material/select';
import {MatToolbarModule } from '@angular/material/toolbar';
import {MatDatepickerModule} from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { MAT_DATE_LOCALE } from '@angular/material/core';
import {MatCheckboxModule} from '@angular/material/checkbox';
import {MatRadioModule} from '@angular/material/radio';


@NgModule({ declarations: [
        AppComponent,
        UserLoginComponent,
        UserSignupComponent,
        DashboardStudentComponent,
        DashboardLecturerComponent,
        DashboardStaffComponent,
        HistoryTabComponent,
        ApplicationStatusComponent,
        ApplicationEditorComponent,
        ApplicationCreatorComponent,
        NavbarComponents,
        RecordsVisualizerComponent,
        AgreementVisualizerComponent
    ],
    bootstrap: [AppComponent], 
    imports: [BrowserModule,
        FormsModule,
        AppRoutingModule,
        MatGridListModule,
        MatCardModule,
        MatMenuModule,
        MatIconModule,
        MatButtonModule,
        MatExpansionModule,
        MatAccordion,
        MatDividerModule,
        MatDialogModule,
        MatTooltipModule,
        MatDialogActions,
        MatDialogClose,
        MatDialogContent,
        MatDialogTitle,
        MatFormFieldModule,
        MatInputModule,
        MatSelectModule,
        MatToolbarModule,
        MatDatepickerModule,
        MatNativeDateModule,
        MatCheckboxModule,
        MatRadioModule], 
    providers: [
        { provide: UserHttpService, useClass: UserHttpService },
        { provide: SocketioService, useClass: SocketioService },
        { provide: AgreementHttpService, useClass: AgreementHttpService },
        { provide: ApplicationHttpService, useClass: ApplicationHttpService },
        { provide: HostHttpService, useClass: HostHttpService },
        { provide: TranscriptRecordHttpService, useClass: TranscriptRecordHttpService },
        { provide: MAT_DATE_LOCALE, useValue: 'en-GB' },
        provideHttpClient(withInterceptorsFromDi())
    ] })
export class AppModule { }
